-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Apr 2021 pada 12.18
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `help`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `account`
--

CREATE TABLE `account` (
  `Username` varchar(52) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Full_Name` varchar(52) NOT NULL,
  `E_Mail` varchar(52) NOT NULL,
  `No_HP` varchar(16) NOT NULL,
  `Access` enum('Administrator','Operator') NOT NULL,
  `Status` enum('ON','OFF') NOT NULL,
  `Block` enum('Y','N') NOT NULL,
  `Created` varchar(10) NOT NULL,
  `History_Login` varchar(22) NOT NULL,
  `History_Logout` varchar(22) NOT NULL,
  `Session_ID` text NOT NULL,
  `Photo` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `account`
--

INSERT INTO `account` (`Username`, `Password`, `Full_Name`, `E_Mail`, `No_HP`, `Access`, `Status`, `Block`, `Created`, `History_Login`, `History_Logout`, `Session_ID`, `Photo`) VALUES
('171011450336', '9653368443d395b7dd53e1649883def6a475e686e1603c69cbe9a30c338479cda0ef73ac1c2b74615e664256ee188389ed52c66a7ca2906b06319bfbdab7222b', 'Husni Mubarok', 'husni@mail.com', '123-456-789-101', 'Administrator', 'ON', 'N', '09-04-2021', '09-04-2021 15:26:26', '', 'rfb22bagq92nl1dhlkitgclb2e', ''),
('kelompok3', '187608520bdb7514b0903205305d9485c9abe1290d149c6d212d72efbf995d2bc603341b667ec8e8fa46b7c93c89382b43a33e0189984040f4fdc3873f65b96b', 'Husni Mubarok', 'husni@mail.com', '081-234-567-891', 'Administrator', 'ON', 'N', '08-04-2021', '09-04-2021 15:12:37', '', '0tfpu92ptsnoi9iu96kk5c0jg2', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bantuan`
--

CREATE TABLE `bantuan` (
  `ID_Bantuan` varchar(16) NOT NULL,
  `Jenis_Alokasi` enum('APD','LM','BKM','HS','SM') NOT NULL,
  `Jumlah_Transaksi` varchar(10) NOT NULL,
  `Jumlah_Dana` varchar(10) NOT NULL,
  `Nama_Lengkap` varchar(52) NOT NULL,
  `No_HP` varchar(16) NOT NULL,
  `Email` varchar(52) NOT NULL,
  `Tanggal` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bantuan`
--

INSERT INTO `bantuan` (`ID_Bantuan`, `Jenis_Alokasi`, `Jumlah_Transaksi`, `Jumlah_Dana`, `Nama_Lengkap`, `No_HP`, `Email`, `Tanggal`) VALUES
('1617733002', 'APD', '182', '171.472.59', 'Husni Mubarok', '083-850-053-002', 'husni6011@gmail.com', 'Friday-09-April-2021 15:15:21'),
('1617956364', 'LM', '138', '135.405.60', 'Husni Mubarok', '081-229-550-255', 'mubarok@gmail.com', 'Friday-09-April-2021 15:19:24');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`Username`);

--
-- Indeks untuk tabel `bantuan`
--
ALTER TABLE `bantuan`
  ADD PRIMARY KEY (`ID_Bantuan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
