<div class="pull-right hidden-xs"><b>Version</b> 1.6.0</div>
<strong>Copyright &copy; <?php Echo date("Y"); ?> <a href="https://Zearch-Soft.Net">Zetix Arch-Soft LLC.</a></strong> All Rights Reserved.